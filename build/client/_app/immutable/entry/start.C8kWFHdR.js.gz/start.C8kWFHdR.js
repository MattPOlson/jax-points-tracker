import{l as o,a as r}from"../chunks/3PQ1VwVZ.js";export{o as load_css,r as start};
