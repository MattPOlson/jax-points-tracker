import{s as mt,n as Ze,d as c,i as x,b as l,q as h,c as f,e as y,v as De,g as P,h as p,j as z,k as et,w as bt,x as vt,r as Qe,a as Z,B as tt,p as he,f as w,z as st,t as j,y as yt}from"../chunks/DOvoZ9Ia.js";import{e as lt}from"../chunks/DJwZhPfI.js";import{S as gt,i as kt}from"../chunks/DZMW2zPD.js";import{g as Ye}from"../chunks/BsRRfQNK.js";import{p as Et}from"../chunks/CvUFp_1t.js";import{u as wt}from"../chunks/DP1yl1qp.js";import{s as Fe}from"../chunks/CCM_4jRA.js";function at(s,e,t){const i=s.slice();return i[32]=e[t],i}function jt(s){let e,t,i=s[5].name+"",a,n,u,g,_,S="Total Entries",M,C,K=s[6].length+"",L,J,se,G,O="Paid Entries",ce,ne,q=s[6].filter(ht).length+"",ie,ue,Y,W,re="Entry Fee",le,ae,fe,I=(s[5].entry_fee||0)+"",H,R,D,N,$="Total Fees",v,d,r,o=s[6].filter(_t).length*(s[5].entry_fee||0)+"",m,V,b,k,F,X,U,ee,Q=s[4].size>0?`(${s[4].size})`:"(All)",T,pe,_e,de,Ae,Te=s[4].size>0?`(${s[4].size})`:"(All)",Pe,me,A,oe,we,ye=s[4].size>0?`(${s[4].size})`:"(All)",be,Ee,Le,ge,ze="← Back",Se,je,Ce,Ie,te=s[4].size>0&&nt(s);function Ge(E,B){return E[0].length===0?Ct:St}let $e=Ge(s),ke=$e(s);return{c(){e=p("div"),t=p("h2"),a=j(i),n=z(),u=p("div"),g=p("div"),_=p("span"),_.textContent=S,M=z(),C=p("span"),L=j(K),J=z(),se=p("div"),G=p("span"),G.textContent=O,ce=z(),ne=p("span"),ie=j(q),ue=z(),Y=p("div"),W=p("span"),W.textContent=re,le=z(),ae=p("span"),fe=j("$"),H=j(I),R=z(),D=p("div"),N=p("span"),N.textContent=$,v=z(),d=p("span"),r=j("$"),m=j(o),V=z(),b=p("div"),k=p("input"),F=z(),te&&te.c(),X=z(),U=p("button"),ee=j("🖨️ Print Labels "),T=j(Q),_e=z(),de=p("button"),Ae=j("📊 Export CSV "),Pe=j(Te),A=z(),oe=p("button"),we=j("📝 Print Judging Sheets "),be=j(ye),Le=z(),ge=p("button"),ge.textContent=ze,Se=z(),ke.c(),je=st(),this.h()},l(E){e=f(E,"DIV",{class:!0});var B=y(e);t=f(B,"H2",{class:!0});var Ke=y(t);a=w(Ke,i),Ke.forEach(c),n=P(B),u=f(B,"DIV",{class:!0});var Ne=y(u);g=f(Ne,"DIV",{class:!0});var Ve=y(g);_=f(Ve,"SPAN",{class:!0,"data-svelte-h":!0}),De(_)!=="svelte-1ly6mm6"&&(_.textContent=S),M=P(Ve),C=f(Ve,"SPAN",{class:!0});var Xe=y(C);L=w(Xe,K),Xe.forEach(c),Ve.forEach(c),J=P(Ne),se=f(Ne,"DIV",{class:!0});var He=y(se);G=f(He,"SPAN",{class:!0,"data-svelte-h":!0}),De(G)!=="svelte-1e7gzoe"&&(G.textContent=O),ce=P(He),ne=f(He,"SPAN",{class:!0});var xe=y(ne);ie=w(xe,q),xe.forEach(c),He.forEach(c),ue=P(Ne),Y=f(Ne,"DIV",{class:!0});var Ue=y(Y);W=f(Ue,"SPAN",{class:!0,"data-svelte-h":!0}),De(W)!=="svelte-1dw3q0"&&(W.textContent=re),le=P(Ue),ae=f(Ue,"SPAN",{class:!0});var Me=y(ae);fe=w(Me,"$"),H=w(Me,I),Me.forEach(c),Ue.forEach(c),R=P(Ne),D=f(Ne,"DIV",{class:!0});var Be=y(D);N=f(Be,"SPAN",{class:!0,"data-svelte-h":!0}),De(N)!=="svelte-1k6mrzd"&&(N.textContent=$),v=P(Be),d=f(Be,"SPAN",{class:!0});var Oe=y(d);r=w(Oe,"$"),m=w(Oe,o),Oe.forEach(c),Be.forEach(c),Ne.forEach(c),B.forEach(c),V=P(E),b=f(E,"DIV",{class:!0});var ve=y(b);k=f(ve,"INPUT",{type:!0,class:!0,placeholder:!0}),F=P(ve),te&&te.l(ve),X=P(ve),U=f(ve,"BUTTON",{class:!0});var Re=y(U);ee=w(Re,"🖨️ Print Labels "),T=w(Re,Q),Re.forEach(c),_e=P(ve),de=f(ve,"BUTTON",{class:!0});var qe=y(de);Ae=w(qe,"📊 Export CSV "),Pe=w(qe,Te),qe.forEach(c),A=P(ve),oe=f(ve,"BUTTON",{class:!0});var Je=y(oe);we=w(Je,"📝 Print Judging Sheets "),be=w(Je,ye),Je.forEach(c),Le=P(ve),ge=f(ve,"BUTTON",{class:!0,"data-svelte-h":!0}),De(ge)!=="svelte-52xzlp"&&(ge.textContent=ze),ve.forEach(c),Se=P(E),ke.l(E),je=st(),this.h()},h(){h(t,"class","svelte-1yscyhl"),h(_,"class","info-label svelte-1yscyhl"),h(C,"class","info-value svelte-1yscyhl"),h(g,"class","info-item svelte-1yscyhl"),h(G,"class","info-label svelte-1yscyhl"),h(ne,"class","info-value svelte-1yscyhl"),h(se,"class","info-item svelte-1yscyhl"),h(W,"class","info-label svelte-1yscyhl"),h(ae,"class","info-value svelte-1yscyhl"),h(Y,"class","info-item svelte-1yscyhl"),h(N,"class","info-label svelte-1yscyhl"),h(d,"class","info-value svelte-1yscyhl"),h(D,"class","info-item svelte-1yscyhl"),h(u,"class","info-grid svelte-1yscyhl"),h(e,"class","competition-info svelte-1yscyhl"),h(k,"type","text"),h(k,"class","search-input svelte-1yscyhl"),h(k,"placeholder","Search entries..."),h(U,"class","btn btn-primary svelte-1yscyhl"),U.disabled=pe=s[0].length===0,h(de,"class","btn btn-success svelte-1yscyhl"),de.disabled=me=s[0].length===0,h(oe,"class","btn btn-info svelte-1yscyhl"),oe.disabled=Ee=s[0].length===0,h(ge,"class","btn btn-secondary svelte-1yscyhl"),h(b,"class","controls svelte-1yscyhl")},m(E,B){x(E,e,B),l(e,t),l(t,a),l(e,n),l(e,u),l(u,g),l(g,_),l(g,M),l(g,C),l(C,L),l(u,J),l(u,se),l(se,G),l(se,ce),l(se,ne),l(ne,ie),l(u,ue),l(u,Y),l(Y,W),l(Y,le),l(Y,ae),l(ae,fe),l(ae,H),l(u,R),l(u,D),l(D,N),l(D,v),l(D,d),l(d,r),l(d,m),x(E,V,B),x(E,b,B),l(b,k),tt(k,s[1]),l(b,F),te&&te.m(b,null),l(b,X),l(b,U),l(U,ee),l(U,T),l(b,_e),l(b,de),l(de,Ae),l(de,Pe),l(b,A),l(b,oe),l(oe,we),l(oe,be),l(b,Le),l(b,ge),x(E,Se,B),ke.m(E,B),x(E,je,B),Ce||(Ie=[he(k,"input",s[19]),he(U,"click",s[13]),he(de,"click",s[15]),he(oe,"click",s[16]),he(ge,"click",s[14])],Ce=!0)},p(E,B){B[0]&32&&i!==(i=E[5].name+"")&&Z(a,i),B[0]&64&&K!==(K=E[6].length+"")&&Z(L,K),B[0]&64&&q!==(q=E[6].filter(ht).length+"")&&Z(ie,q),B[0]&32&&I!==(I=(E[5].entry_fee||0)+"")&&Z(H,I),B[0]&96&&o!==(o=E[6].filter(_t).length*(E[5].entry_fee||0)+"")&&Z(m,o),B[0]&2&&k.value!==E[1]&&tt(k,E[1]),E[4].size>0?te?te.p(E,B):(te=nt(E),te.c(),te.m(b,X)):te&&(te.d(1),te=null),B[0]&16&&Q!==(Q=E[4].size>0?`(${E[4].size})`:"(All)")&&Z(T,Q),B[0]&1&&pe!==(pe=E[0].length===0)&&(U.disabled=pe),B[0]&16&&Te!==(Te=E[4].size>0?`(${E[4].size})`:"(All)")&&Z(Pe,Te),B[0]&1&&me!==(me=E[0].length===0)&&(de.disabled=me),B[0]&16&&ye!==(ye=E[4].size>0?`(${E[4].size})`:"(All)")&&Z(be,ye),B[0]&1&&Ee!==(Ee=E[0].length===0)&&(oe.disabled=Ee),$e===($e=Ge(E))&&ke?ke.p(E,B):(ke.d(1),ke=$e(E),ke&&(ke.c(),ke.m(je.parentNode,je)))},d(E){E&&(c(e),c(V),c(b),c(Se),c(je)),te&&te.d(),ke.d(E),Ce=!1,Qe(Ie)}}}function Tt(s){let e,t='<div class="spinner svelte-1yscyhl"></div> <p>Loading entries...</p>';return{c(){e=p("div"),e.innerHTML=t,this.h()},l(i){e=f(i,"DIV",{class:!0,"data-svelte-h":!0}),De(e)!=="svelte-e96xyd"&&(e.innerHTML=t),this.h()},h(){h(e,"class","loading svelte-1yscyhl")},m(i,a){x(i,e,a)},p:Ze,d(i){i&&c(e)}}}function nt(s){let e,t=s[4].size+"",i,a;return{c(){e=p("span"),i=j(t),a=j(" selected"),this.h()},l(n){e=f(n,"SPAN",{class:!0});var u=y(e);i=w(u,t),a=w(u," selected"),u.forEach(c),this.h()},h(){h(e,"class","selected-count svelte-1yscyhl")},m(n,u){x(n,e,u),l(e,i),l(e,a)},p(n,u){u[0]&16&&t!==(t=n[4].size+"")&&Z(i,t)},d(n){n&&c(e)}}}function St(s){let e,t,i,a,n,u,g,_,S,M,C,K,L,J,se,G,O,ce,ne,q,ie,ue,Y,W,re,le,ae,fe,I=s[2]==="entry_number"&&it(s),H=s[2]==="member_name"&&rt(s),R=s[2]==="beer_name"&&ot(s),D=s[2]==="category"&&ct(s),N=s[2]==="paid"&&dt(s),$=s[2]==="submitted_at"&&ut(s),v=lt(s[0]),d=[];for(let r=0;r<v.length;r+=1)d[r]=pt(at(s,v,r));return{c(){e=p("div"),t=p("table"),i=p("thead"),a=p("tr"),n=p("th"),u=p("input"),g=z(),_=p("th"),S=j(`Entry #
                `),I&&I.c(),M=z(),C=p("th"),K=j(`Member
                `),H&&H.c(),L=z(),J=p("th"),se=j(`Beer Name
                `),R&&R.c(),G=z(),O=p("th"),ce=j(`Category
                `),D&&D.c(),ne=z(),q=p("th"),ie=j(`Paid
                `),N&&N.c(),ue=z(),Y=p("th"),W=j(`Submitted
                `),$&&$.c(),re=z(),le=p("tbody");for(let r=0;r<d.length;r+=1)d[r].c();this.h()},l(r){e=f(r,"DIV",{class:!0});var o=y(e);t=f(o,"TABLE",{class:!0});var m=y(t);i=f(m,"THEAD",{});var V=y(i);a=f(V,"TR",{class:!0});var b=y(a);n=f(b,"TH",{class:!0});var k=y(n);u=f(k,"INPUT",{type:!0}),k.forEach(c),g=P(b),_=f(b,"TH",{class:!0});var F=y(_);S=w(F,`Entry #
                `),I&&I.l(F),F.forEach(c),M=P(b),C=f(b,"TH",{class:!0});var X=y(C);K=w(X,`Member
                `),H&&H.l(X),X.forEach(c),L=P(b),J=f(b,"TH",{class:!0});var U=y(J);se=w(U,`Beer Name
                `),R&&R.l(U),U.forEach(c),G=P(b),O=f(b,"TH",{class:!0});var ee=y(O);ce=w(ee,`Category
                `),D&&D.l(ee),ee.forEach(c),ne=P(b),q=f(b,"TH",{class:!0});var Q=y(q);ie=w(Q,`Paid
                `),N&&N.l(Q),Q.forEach(c),ue=P(b),Y=f(b,"TH",{class:!0});var T=y(Y);W=w(T,`Submitted
                `),$&&$.l(T),T.forEach(c),b.forEach(c),V.forEach(c),re=P(m),le=f(m,"TBODY",{});var pe=y(le);for(let _e=0;_e<d.length;_e+=1)d[_e].l(pe);pe.forEach(c),m.forEach(c),o.forEach(c),this.h()},h(){h(u,"type","checkbox"),u.checked=s[8],h(n,"class","checkbox-cell svelte-1yscyhl"),h(_,"class","svelte-1yscyhl"),h(C,"class","svelte-1yscyhl"),h(J,"class","svelte-1yscyhl"),h(O,"class","svelte-1yscyhl"),h(q,"class","svelte-1yscyhl"),h(Y,"class","svelte-1yscyhl"),h(a,"class","svelte-1yscyhl"),h(t,"class","svelte-1yscyhl"),h(e,"class","entries-table svelte-1yscyhl")},m(r,o){x(r,e,o),l(e,t),l(t,i),l(i,a),l(a,n),l(n,u),l(a,g),l(a,_),l(_,S),I&&I.m(_,null),l(a,M),l(a,C),l(C,K),H&&H.m(C,null),l(a,L),l(a,J),l(J,se),R&&R.m(J,null),l(a,G),l(a,O),l(O,ce),D&&D.m(O,null),l(a,ne),l(a,q),l(q,ie),N&&N.m(q,null),l(a,ue),l(a,Y),l(Y,W),$&&$.m(Y,null),l(t,re),l(t,le);for(let m=0;m<d.length;m+=1)d[m]&&d[m].m(le,null);ae||(fe=[he(u,"change",s[11]),he(_,"click",s[20]),he(C,"click",s[21]),he(J,"click",s[22]),he(O,"click",s[23]),he(q,"click",s[24]),he(Y,"click",s[25])],ae=!0)},p(r,o){if(o[0]&256&&(u.checked=r[8]),r[2]==="entry_number"?I?I.p(r,o):(I=it(r),I.c(),I.m(_,null)):I&&(I.d(1),I=null),r[2]==="member_name"?H?H.p(r,o):(H=rt(r),H.c(),H.m(C,null)):H&&(H.d(1),H=null),r[2]==="beer_name"?R?R.p(r,o):(R=ot(r),R.c(),R.m(J,null)):R&&(R.d(1),R=null),r[2]==="category"?D?D.p(r,o):(D=ct(r),D.c(),D.m(O,null)):D&&(D.d(1),D=null),r[2]==="paid"?N?N.p(r,o):(N=dt(r),N.c(),N.m(q,null)):N&&(N.d(1),N=null),r[2]==="submitted_at"?$?$.p(r,o):($=ut(r),$.c(),$.m(Y,null)):$&&($.d(1),$=null),o[0]&5137){v=lt(r[0]);let m;for(m=0;m<v.length;m+=1){const V=at(r,v,m);d[m]?d[m].p(V,o):(d[m]=pt(V),d[m].c(),d[m].m(le,null))}for(;m<d.length;m+=1)d[m].d(1);d.length=v.length}},d(r){r&&c(e),I&&I.d(),H&&H.d(),R&&R.d(),D&&D.d(),N&&N.d(),$&&$.d(),yt(d,r),ae=!1,Qe(fe)}}}function Ct(s){let e,t,i="No entries found",a,n;function u(S,M){return S[1]?Dt:Nt}let g=u(s),_=g(s);return{c(){e=p("div"),t=p("h3"),t.textContent=i,a=z(),n=p("p"),_.c(),this.h()},l(S){e=f(S,"DIV",{class:!0});var M=y(e);t=f(M,"H3",{"data-svelte-h":!0}),De(t)!=="svelte-12l3juz"&&(t.textContent=i),a=P(M),n=f(M,"P",{});var C=y(n);_.l(C),C.forEach(c),M.forEach(c),this.h()},h(){h(e,"class","empty-state svelte-1yscyhl")},m(S,M){x(S,e,M),l(e,t),l(e,a),l(e,n),_.m(n,null)},p(S,M){g!==(g=u(S))&&(_.d(1),_=g(S),_&&(_.c(),_.m(n,null)))},d(S){S&&c(e),_.d()}}}function it(s){let e,t=s[3]==="asc"?"↑":"↓",i;return{c(){e=p("span"),i=j(t),this.h()},l(a){e=f(a,"SPAN",{class:!0});var n=y(e);i=w(n,t),n.forEach(c),this.h()},h(){h(e,"class","sort-indicator svelte-1yscyhl")},m(a,n){x(a,e,n),l(e,i)},p(a,n){n[0]&8&&t!==(t=a[3]==="asc"?"↑":"↓")&&Z(i,t)},d(a){a&&c(e)}}}function rt(s){let e,t=s[3]==="asc"?"↑":"↓",i;return{c(){e=p("span"),i=j(t),this.h()},l(a){e=f(a,"SPAN",{class:!0});var n=y(e);i=w(n,t),n.forEach(c),this.h()},h(){h(e,"class","sort-indicator svelte-1yscyhl")},m(a,n){x(a,e,n),l(e,i)},p(a,n){n[0]&8&&t!==(t=a[3]==="asc"?"↑":"↓")&&Z(i,t)},d(a){a&&c(e)}}}function ot(s){let e,t=s[3]==="asc"?"↑":"↓",i;return{c(){e=p("span"),i=j(t),this.h()},l(a){e=f(a,"SPAN",{class:!0});var n=y(e);i=w(n,t),n.forEach(c),this.h()},h(){h(e,"class","sort-indicator svelte-1yscyhl")},m(a,n){x(a,e,n),l(e,i)},p(a,n){n[0]&8&&t!==(t=a[3]==="asc"?"↑":"↓")&&Z(i,t)},d(a){a&&c(e)}}}function ct(s){let e,t=s[3]==="asc"?"↑":"↓",i;return{c(){e=p("span"),i=j(t),this.h()},l(a){e=f(a,"SPAN",{class:!0});var n=y(e);i=w(n,t),n.forEach(c),this.h()},h(){h(e,"class","sort-indicator svelte-1yscyhl")},m(a,n){x(a,e,n),l(e,i)},p(a,n){n[0]&8&&t!==(t=a[3]==="asc"?"↑":"↓")&&Z(i,t)},d(a){a&&c(e)}}}function dt(s){let e,t=s[3]==="asc"?"↑":"↓",i;return{c(){e=p("span"),i=j(t),this.h()},l(a){e=f(a,"SPAN",{class:!0});var n=y(e);i=w(n,t),n.forEach(c),this.h()},h(){h(e,"class","sort-indicator svelte-1yscyhl")},m(a,n){x(a,e,n),l(e,i)},p(a,n){n[0]&8&&t!==(t=a[3]==="asc"?"↑":"↓")&&Z(i,t)},d(a){a&&c(e)}}}function ut(s){let e,t=s[3]==="asc"?"↑":"↓",i;return{c(){e=p("span"),i=j(t),this.h()},l(a){e=f(a,"SPAN",{class:!0});var n=y(e);i=w(n,t),n.forEach(c),this.h()},h(){h(e,"class","sort-indicator svelte-1yscyhl")},m(a,n){x(a,e,n),l(e,i)},p(a,n){n[0]&8&&t!==(t=a[3]==="asc"?"↑":"↓")&&Z(i,t)},d(a){a&&c(e)}}}function ft(s){let e,t,i=s[32].bjcp_category.category_name+"",a;return{c(){e=p("br"),t=p("small"),a=j(i)},l(n){e=f(n,"BR",{}),t=f(n,"SMALL",{});var u=y(t);a=w(u,i),u.forEach(c)},m(n,u){x(n,e,u),x(n,t,u),l(t,a)},p(n,u){u[0]&1&&i!==(i=n[32].bjcp_category.category_name+"")&&Z(a,i)},d(n){n&&(c(e),c(t))}}}function pt(s){var _e,de,Ae,Te,Pe;let e,t,i,a,n,u,g,_=s[32].entry_number+"",S,M,C,K,L=((_e=s[32].members)==null?void 0:_e.name)+"",J,se,G,O=((de=s[32].members)==null?void 0:de.email)+"",ce,ne,q,ie=(s[32].beer_name||"-")+"",ue,Y,W,re,le=(((Ae=s[32].bjcp_category)==null?void 0:Ae.category_number)||"")+"",ae,fe=(((Te=s[32].bjcp_category)==null?void 0:Te.subcategory_letter)||"")+"",I,H,R,D,N,$,v,d,r,o=s[32].is_paid?"Paid":"Unpaid",m,V,b,k=We(s[32].submitted_at)+"",F,X,U,ee;function Q(){return s[26](s[32])}let T=((Pe=s[32].bjcp_category)==null?void 0:Pe.category_name)&&ft(s);function pe(){return s[27](s[32])}return{c(){e=p("tr"),t=p("td"),i=p("input"),n=z(),u=p("td"),g=p("span"),S=j(_),M=z(),C=p("td"),K=p("div"),J=j(L),se=z(),G=p("small"),ce=j(O),ne=z(),q=p("td"),ue=j(ie),Y=z(),W=p("td"),re=p("span"),ae=j(le),I=j(fe),H=z(),T&&T.c(),R=z(),D=p("td"),N=p("div"),$=p("div"),d=z(),r=p("span"),m=j(o),V=z(),b=p("td"),F=j(k),X=z(),this.h()},l(me){e=f(me,"TR",{class:!0});var A=y(e);t=f(A,"TD",{class:!0});var oe=y(t);i=f(oe,"INPUT",{type:!0}),oe.forEach(c),n=P(A),u=f(A,"TD",{class:!0});var we=y(u);g=f(we,"SPAN",{class:!0});var ye=y(g);S=w(ye,_),ye.forEach(c),we.forEach(c),M=P(A),C=f(A,"TD",{class:!0});var be=y(C);K=f(be,"DIV",{});var Ee=y(K);J=w(Ee,L),Ee.forEach(c),se=P(be),G=f(be,"SMALL",{});var Le=y(G);ce=w(Le,O),Le.forEach(c),be.forEach(c),ne=P(A),q=f(A,"TD",{class:!0});var ge=y(q);ue=w(ge,ie),ge.forEach(c),Y=P(A),W=f(A,"TD",{class:!0});var ze=y(W);re=f(ze,"SPAN",{class:!0});var Se=y(re);ae=w(Se,le),I=w(Se,fe),Se.forEach(c),H=P(ze),T&&T.l(ze),ze.forEach(c),R=P(A),D=f(A,"TD",{class:!0});var je=y(D);N=f(je,"DIV",{class:!0});var Ce=y(N);$=f(Ce,"DIV",{class:!0}),y($).forEach(c),d=P(Ce),r=f(Ce,"SPAN",{});var Ie=y(r);m=w(Ie,o),Ie.forEach(c),Ce.forEach(c),je.forEach(c),V=P(A),b=f(A,"TD",{class:!0});var te=y(b);F=w(te,k),te.forEach(c),X=P(A),A.forEach(c),this.h()},h(){h(i,"type","checkbox"),i.checked=a=s[4].has(s[32].id),h(t,"class","checkbox-cell svelte-1yscyhl"),h(g,"class","entry-number svelte-1yscyhl"),h(u,"class","svelte-1yscyhl"),h(C,"class","svelte-1yscyhl"),h(q,"class","svelte-1yscyhl"),h(re,"class","category-badge svelte-1yscyhl"),h(W,"class","svelte-1yscyhl"),h($,"class",v="toggle-switch "+(s[32].is_paid?"active":"")+" svelte-1yscyhl"),h(N,"class","payment-toggle svelte-1yscyhl"),h(D,"class","svelte-1yscyhl"),h(b,"class","svelte-1yscyhl"),h(e,"class","svelte-1yscyhl")},m(me,A){x(me,e,A),l(e,t),l(t,i),l(e,n),l(e,u),l(u,g),l(g,S),l(e,M),l(e,C),l(C,K),l(K,J),l(C,se),l(C,G),l(G,ce),l(e,ne),l(e,q),l(q,ue),l(e,Y),l(e,W),l(W,re),l(re,ae),l(re,I),l(W,H),T&&T.m(W,null),l(e,R),l(e,D),l(D,N),l(N,$),l(N,d),l(N,r),l(r,m),l(e,V),l(e,b),l(b,F),l(e,X),U||(ee=[he(i,"change",Q),he($,"click",pe)],U=!0)},p(me,A){var oe,we,ye,be,Ee;s=me,A[0]&17&&a!==(a=s[4].has(s[32].id))&&(i.checked=a),A[0]&1&&_!==(_=s[32].entry_number+"")&&Z(S,_),A[0]&1&&L!==(L=((oe=s[32].members)==null?void 0:oe.name)+"")&&Z(J,L),A[0]&1&&O!==(O=((we=s[32].members)==null?void 0:we.email)+"")&&Z(ce,O),A[0]&1&&ie!==(ie=(s[32].beer_name||"-")+"")&&Z(ue,ie),A[0]&1&&le!==(le=(((ye=s[32].bjcp_category)==null?void 0:ye.category_number)||"")+"")&&Z(ae,le),A[0]&1&&fe!==(fe=(((be=s[32].bjcp_category)==null?void 0:be.subcategory_letter)||"")+"")&&Z(I,fe),(Ee=s[32].bjcp_category)!=null&&Ee.category_name?T?T.p(s,A):(T=ft(s),T.c(),T.m(W,null)):T&&(T.d(1),T=null),A[0]&1&&v!==(v="toggle-switch "+(s[32].is_paid?"active":"")+" svelte-1yscyhl")&&h($,"class",v),A[0]&1&&o!==(o=s[32].is_paid?"Paid":"Unpaid")&&Z(m,o),A[0]&1&&k!==(k=We(s[32].submitted_at)+"")&&Z(F,k)},d(me){me&&c(e),T&&T.d(),U=!1,Qe(ee)}}}function Nt(s){let e;return{c(){e=j("No entries have been submitted yet")},l(t){e=w(t,"No entries have been submitted yet")},m(t,i){x(t,e,i)},d(t){t&&c(e)}}}function Dt(s){let e;return{c(){e=j("Try adjusting your search")},l(t){e=w(t,"Try adjusting your search")},m(t,i){x(t,e,i)},d(t){t&&c(e)}}}function Pt(s){let e,t,i='<h1 class="svelte-1yscyhl"><span class="emoji svelte-1yscyhl">📋</span> Competition Entries</h1> <p class="subtitle svelte-1yscyhl">Manage entries and print labels</p>',a;function n(_,S){if(_[7])return Tt;if(_[5])return jt}let u=n(s),g=u&&u(s);return{c(){e=p("div"),t=p("div"),t.innerHTML=i,a=z(),g&&g.c(),this.h()},l(_){e=f(_,"DIV",{class:!0});var S=y(e);t=f(S,"DIV",{class:!0,"data-svelte-h":!0}),De(t)!=="svelte-7nznvx"&&(t.innerHTML=i),a=P(S),g&&g.l(S),S.forEach(c),this.h()},h(){h(t,"class","hero svelte-1yscyhl"),h(e,"class","container svelte-1yscyhl")},m(_,S){x(_,e,S),l(e,t),l(e,a),g&&g.m(e,null)},p(_,S){u===(u=n(_))&&g?g.p(_,S):(g&&g.d(1),g=u&&u(_),g&&(g.c(),g.m(e,null)))},i:Ze,o:Ze,d(_){_&&c(e),g&&g.d()}}}function We(s){if(!s||s===null||s===void 0)return"No date";try{const e=String(s).trim();let t=e;if(e.includes(" ")&&!e.includes("T")){if(t=e.replace(" ","T"),t.includes(".")){const[a,n]=t.split("."),u=n.substring(0,3);t=`${a}.${u}`}!t.includes("+")&&!t.includes("Z")&&(t+="Z")}const i=new Date(t);return isNaN(i.getTime())?(console.warn("Invalid date after parsing:",e,"->",t),"Invalid Date"):i.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric",hour:"2-digit",minute:"2-digit"})}catch(e){return console.warn("Error formatting date:",s,e),"Invalid Date"}}const ht=s=>s.is_paid,_t=s=>s.is_paid;function zt(s,e,t){let i,a,n;et(s,Et,v=>t(17,a=v)),et(s,wt,v=>t(18,n=v));let u=null,g=[],_=[],S=!0,M="",C="entry_number",K="asc",L=new Set,J=!1;bt(()=>{se()}),vt(()=>{});async function se(){t(7,S=!0);try{const{data:v,error:d}=await Fe.from("competitions").select("*").eq("id",i).single();if(d)throw d;t(5,u=v);const{data:r,error:o}=await Fe.from("competition_entries").select(`
          *,
          members!inner(
            name,
            email,
            phone
          ),
          bjcp_category:bjcp_categories(
            id,
            category_number,
            subcategory_letter,
            subcategory_name,
            category_name
          )
        `).eq("competition_id",i).order("entry_number");if(o)throw o;t(6,g=r||[]),G()}catch(v){console.error("Error loading data:",v),alert("Failed to load competition entries"),Ye("/officers/manage-competitions")}finally{t(7,S=!1)}}function G(){let v=[...g];if(M.trim()){const d=M.toLowerCase();v=v.filter(r=>{var o,m,V,b,k,F,X,U,ee,Q,T,pe;return((o=r.entry_number)==null?void 0:o.toLowerCase().includes(d))||((m=r.beer_name)==null?void 0:m.toLowerCase().includes(d))||((b=(V=r.members)==null?void 0:V.name)==null?void 0:b.toLowerCase().includes(d))||((F=(k=r.members)==null?void 0:k.email)==null?void 0:F.toLowerCase().includes(d))||((U=(X=r.bjcp_category)==null?void 0:X.category_name)==null?void 0:U.toLowerCase().includes(d))||`${(ee=r.bjcp_category)==null?void 0:ee.category_number}${(Q=r.bjcp_category)==null?void 0:Q.subcategory_letter}`.toLowerCase().includes(d)||((T=r.special_ingredients)==null?void 0:T.toLowerCase().includes(d))||((pe=r.notes)==null?void 0:pe.toLowerCase().includes(d))})}v.sort((d,r)=>{var V,b,k,F,X,U;let o,m;switch(C){case"entry_number":o=d.entry_number||"",m=r.entry_number||"";break;case"member_name":o=((V=d.members)==null?void 0:V.name)||"",m=((b=r.members)==null?void 0:b.name)||"";break;case"beer_name":o=d.beer_name||"",m=r.beer_name||"";break;case"category":o=`${((k=d.bjcp_category)==null?void 0:k.category_number)||""}${((F=d.bjcp_category)==null?void 0:F.subcategory_letter)||""}`,m=`${((X=r.bjcp_category)==null?void 0:X.category_number)||""}${((U=r.bjcp_category)==null?void 0:U.subcategory_letter)||""}`;break;case"paid":o=d.is_paid?1:0,m=r.is_paid?1:0;break;case"submitted_at":const ee=Q=>{if(!Q)return new Date(0);let T=Q;if(Q.includes(" ")&&!Q.includes("T")){if(T=Q.replace(" ","T"),T.includes(".")){const[pe,_e]=T.split("."),de=_e.substring(0,3);T=`${pe}.${de}`}!T.includes("+")&&!T.includes("Z")&&(T+="Z")}return new Date(T)};o=ee(d.submitted_at),m=ee(r.submitted_at);break;default:o=d[C]||"",m=r[C]||""}return K==="asc"?o>m?1:o<m?-1:0:o<m?1:o>m?-1:0}),t(0,_=v)}function O(v){C===v?t(3,K=K==="asc"?"desc":"asc"):(t(2,C=v),t(3,K="asc")),G()}function ce(v){L.has(v)?L.delete(v):L.add(v),t(4,L=new Set(L))}function ne(){J?L.clear():_.forEach(v=>L.add(v.id)),t(4,L=new Set(L)),t(8,J=!J)}async function q(v,d){try{const{error:r}=await Fe.from("competition_entries").update({is_paid:d,payment_date:d?new Date().toISOString():null}).eq("id",v);if(r)throw r;const o=g.findIndex(m=>m.id===v);o!==-1&&(t(6,g[o].is_paid=d,g),t(6,g[o].payment_date=d?new Date().toISOString():null,g),G())}catch(r){console.error("Error updating payment status:",r),alert("Failed to update payment status")}}function ie(){const v=L.size>0?_.filter(o=>L.has(o.id)):_;if(v.length===0){alert("No entries selected for printing");return}const d=window.open("","_blank"),r=v.flatMap(o=>{var V,b,k,F;const m=`
      <div class="label">
        <div class="label-header">
          <strong>${(u==null?void 0:u.name)||"Competition"}</strong>
        </div>
        <div class="entry-number">
          Entry #: <span>${o.entry_number}</span>
        </div>
        <div class="beer-style">
          Style: <span>${((V=o.bjcp_category)==null?void 0:V.category_number)||""}${((b=o.bjcp_category)==null?void 0:b.subcategory_letter)||""}</span> - ${((k=o.bjcp_category)==null?void 0:k.category_name)||""}
          ${(F=o.bjcp_category)!=null&&F.subcategory_name?`<br><small>${o.bjcp_category.subcategory_name}</small>`:""}
          ${o.beer_notes?`<br><small>Special: ${o.beer_notes}</small>`:""}
        </div>
        ${o.notes?`
          <div class="notes">
            Notes: ${o.notes}
          </div>
        `:""}
      </div>
    `;return[m,m,m]}).join("");d.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Competition Entry Labels</title>
      <style>
        @page {
          size: 8.5in 11in;
          margin: 0.5in;
        }
        body {
          margin: 0;
          padding: 0;
          font-family: Arial, sans-serif;
        }
        .labels-container {
          display: flex;
          flex-wrap: wrap;
          gap: 0.1875in;
          justify-content: flex-start;
        }
        .label {
          width: 2.25in;
          height: 2.25in;
          padding: 0.125in;
          box-sizing: border-box;
          border: 1px solid #000;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          margin-bottom: 0.1875in;
          break-inside: avoid;
        }
        .label-header {
          font-size: 10pt;
          text-align: center;
          margin-bottom: 0.1in;
          border-bottom: 1px solid #000;
          padding-bottom: 0.05in;
        }
        .entry-number {
          font-size: 14pt;
          font-weight: bold;
          margin-bottom: 0.1in;
        }
        .entry-number span {
          font-size: 18pt;
          color: #ff3e00;
        }
        .beer-style {
          font-size: 10pt;
          margin-bottom: 0.1in;
        }
        .beer-style span {
          font-weight: bold;
          font-size: 12pt;
        }
        .beer-style small {
          font-size: 9pt;
        }
        .special, .notes {
          font-size: 9pt;
          margin-top: 0.05in;
          padding-top: 0.05in;
          border-top: 1px solid #ccc;
        }
        @media print {
          .label {
            border: 1px solid #000 !important;
          }
          body {
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
        }
      </style>
    </head>
    <body>
      <div class="labels-container">
        ${r}
      </div>
    </body>
    </html>
  `),d.document.close(),d.focus(),setTimeout(()=>{d.print(),d.close()},250)}function ue(){Ye("/officers/manage-competitions")}function Y(){const v=L.size>0?_.filter(k=>L.has(k.id)):_;if(v.length===0){alert("No entries to export");return}const o=[["Entry Number","Member Name","Beer Name","Category Number","Category Name","Subcategory Name","Paid","Submitted Date"].join(","),...v.map(k=>{var F,X,U,ee,Q;return[k.entry_number||"",`"${((F=k.members)==null?void 0:F.name)||""}"`,`"${k.beer_name||""}"`,`${((X=k.bjcp_category)==null?void 0:X.category_number)||""}${((U=k.bjcp_category)==null?void 0:U.subcategory_letter)||""}`,`"${((ee=k.bjcp_category)==null?void 0:ee.category_name)||""}"`,`"${((Q=k.bjcp_category)==null?void 0:Q.subcategory_name)||""}"`,k.is_paid?"Yes":"No",We(k.submitted_at)].join(",")})].join(`
`),m=new Blob([o],{type:"text/csv"}),V=window.URL.createObjectURL(m),b=document.createElement("a");b.href=V,b.download=`${(u==null?void 0:u.name)||"competition"}_entries_${new Date().toISOString().split("T")[0]}.csv`,document.body.appendChild(b),b.click(),document.body.removeChild(b),window.URL.revokeObjectURL(V)}function W(){const v=L.size>0?_.filter(o=>L.has(o.id)):_;if(v.length===0){alert("No entries to print judging sheets for");return}const d=window.open("","_blank"),r=re(v);d.document.write(r),d.document.close(),d.onload=()=>{d.print(),d.close()}}function re(v){const d=(u==null?void 0:u.name)||"Competition",r=new Date().toLocaleDateString();return`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Judging Sheet - ${d}</title>
          <style>
            @media print {
              body { margin: 0; }
              .page-break { page-break-before: always; }
            }
            
            body {
              font-family: Arial, sans-serif;
              font-size: 12px;
              line-height: 1.4;
              margin: 20px;
            }
            
            .header {
              text-align: center;
              margin-bottom: 30px;
              border-bottom: 2px solid #333;
              padding-bottom: 15px;
            }
            
            .competition-title {
              font-size: 18px;
              font-weight: bold;
              margin-bottom: 5px;
            }
            
            .judge-info {
              margin: 20px 0;
              border: 1px solid #666;
              padding: 15px;
            }
            
            .judge-line {
              display: inline-block;
              border-bottom: 1px solid #333;
              width: 200px;
              height: 20px;
              margin: 0 10px;
            }
            
            .entries-section {
              margin: 20px 0;
            }
            
            .entry-item {
              border: 1px solid #ccc;
              margin-bottom: 15px;
              padding: 10px;
              background-color: #fafafa;
            }
            
            .entry-header {
              font-weight: bold;
              margin-bottom: 8px;
              display: flex;
              justify-content: space-between;
            }
            
            .entry-number {
              font-size: 14px;
              color: #000;
            }
            
            .beer-style {
              color: #666;
              font-size: 11px;
            }
            
            .tasting-notes {
              margin-top: 10px;
            }
            
            .notes-label {
              font-weight: bold;
              margin-bottom: 5px;
            }
            
            .notes-lines {
              border-bottom: 1px solid #ccc;
              height: 80px;
              margin-bottom: 10px;
            }
            
            .top-picks {
              margin-top: 40px;
              border: 2px solid #333;
              padding: 20px;
              background-color: #f0f0f0;
              page-break-inside: avoid;
              break-inside: avoid;
            }
            
            .top-picks-title {
              font-size: 16px;
              font-weight: bold;
              text-align: center;
              margin-bottom: 20px;
            }
            
            .pick-line {
              margin: 15px 0;
              font-size: 14px;
            }
            
            .pick-number {
              display: inline-block;
              border-bottom: 2px solid #333;
              width: 100px;
              height: 25px;
              margin-left: 20px;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="competition-title">${d} - Judging Sheet</div>
            <div>Date: ${r}</div>
          </div>
          
          <div class="judge-info">
            <strong>Judge Name:</strong> <span class="judge-line"></span>
            <strong style="margin-left: 40px;">Signature:</strong> <span class="judge-line"></span>
          </div>
          
          <div class="entries-section">
            ${v.map(o=>{var m,V,b,k;return`
              <div class="entry-item">
                <div class="entry-header">
                  <div class="entry-number">Entry #${o.entry_number}</div>
                  <div class="beer-style">
                    ${((m=o.bjcp_category)==null?void 0:m.category_number)||""}${((V=o.bjcp_category)==null?void 0:V.subcategory_letter)||""} - 
                    ${((b=o.bjcp_category)==null?void 0:b.category_name)||"Unknown Category"}${(k=o.bjcp_category)!=null&&k.subcategory_name?` - ${o.bjcp_category.subcategory_name}`:""}
                  </div>
                </div>
                ${o.beer_notes?`<div><strong>Additional Notes:</strong> ${o.beer_notes}</div>`:""}
                <div class="tasting-notes">
                  <div class="notes-label">Tasting Notes:</div>
                  <div class="notes-lines"></div>
                </div>
              </div>
            `}).join("")}
          </div>
          
          <div class="top-picks">
            <div class="top-picks-title">Your Top 3 Picks</div>
            <div class="pick-line">
              <strong>1st Place Entry #:</strong> <span class="pick-number"></span>
            </div>
            <div class="pick-line">
              <strong>2nd Place Entry #:</strong> <span class="pick-number"></span>
            </div>
            <div class="pick-line">
              <strong>3rd Place Entry #:</strong> <span class="pick-number"></span>
            </div>
          </div>
        </body>
      </html>
    `}function le(){M=this.value,t(1,M)}const ae=()=>O("entry_number"),fe=()=>O("member_name"),I=()=>O("beer_name"),H=()=>O("category"),R=()=>O("paid"),D=()=>O("submitted_at"),N=v=>ce(v.id),$=v=>q(v.id,!v.is_paid);return s.$$.update=()=>{s.$$.dirty[0]&262144&&n&&!n.is_officer&&Ye("/"),s.$$.dirty[0]&131072&&(i=a.params.id),s.$$.dirty[0]&14&&G(),s.$$.dirty[0]&17&&t(8,J=L.size===_.length&&_.length>0)},[_,M,C,K,L,u,g,S,J,O,ce,ne,q,ie,ue,Y,W,a,n,le,ae,fe,I,H,R,D,N,$]}class Bt extends gt{constructor(e){super(),kt(this,e,zt,Pt,mt,{},null,[-1,-1])}}export{Bt as component};
